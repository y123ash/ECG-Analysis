class CognitiveCore:
    def __init__(self, memory, tools, router):
        self.memory = memory
        self.tools = tools
        self.router = router

    def think(self, query: str) -> str:
        return self.router.route(query, self.memory, self.tools)
