class MemoryEngine:
    def __init__(self):
        self.history = []

    def store(self, query, response):
        self.history.append({"query": query, "response": response})

    def retrieve(self):
        return self.history[-5:]
