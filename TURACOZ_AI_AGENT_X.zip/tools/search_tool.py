class SearchTool:
    def execute(self, query):
        return f"Search results for: {query}"
