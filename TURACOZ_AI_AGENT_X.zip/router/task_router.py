class TaskRouter:
    def route(self, query: str, memory, tools):
        if "search" in query.lower():
            return tools["search"].execute(query)
        elif "tool:" in query.lower():
            tool_name = query.lower().split("tool:")[-1].strip()
            return tools.get(tool_name, lambda q: "Unknown tool")(query)
        return "Task not understood"
