from tools.search_tool import SearchTool

def get_tools():
    return {
        "search": SearchTool(),
    }
