from core.brain import CognitiveCore
from memory.memory_engine import MemoryEngine
from router.task_router import TaskRouter
from tools.tool_registry import get_tools

if __name__ == "__main__":
    memory = MemoryEngine()
    router = TaskRouter()
    tools = get_tools()
    agent = CognitiveCore(memory, tools, router)

    while True:
        query = input("YOU: ")
        response = agent.think(query)
        print("AGENT:", response)
        memory.store(query, response)
